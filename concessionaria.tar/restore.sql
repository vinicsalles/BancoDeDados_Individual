--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE concessionaria;
--
-- Name: concessionaria; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE concessionaria WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE concessionaria OWNER TO postgres;

\connect concessionaria

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: carro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carro (
    car_cd_id integer NOT NULL,
    car_tx_nome character varying(25),
    car_tx_modelo character varying(25),
    car_tx_marca character varying(25),
    car_tx_placa character varying(6) NOT NULL,
    car_int_anofabricacao integer,
    car_fl_valor double precision
);


ALTER TABLE public.carro OWNER TO postgres;

--
-- Name: carro_car_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.carro_car_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.carro_car_cd_id_seq OWNER TO postgres;

--
-- Name: carro_car_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.carro_car_cd_id_seq OWNED BY public.carro.car_cd_id;


--
-- Name: concessionaria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.concessionaria (
    conc_cd_id integer NOT NULL,
    conc_tx_nome character varying(25),
    conc_tx_cnpj character varying(14),
    conc_tx_telefone character varying(14),
    conc_fl_valortotal double precision,
    conc_dt_datavenda date,
    conc_fk_pes integer NOT NULL,
    conc_fk_car integer NOT NULL,
    conc_fk_end integer NOT NULL
);


ALTER TABLE public.concessionaria OWNER TO postgres;

--
-- Name: concessionaria_conc_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.concessionaria_conc_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.concessionaria_conc_cd_id_seq OWNER TO postgres;

--
-- Name: concessionaria_conc_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.concessionaria_conc_cd_id_seq OWNED BY public.concessionaria.conc_cd_id;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endereco (
    end_cd_id integer NOT NULL,
    end_tx_cep character varying(10) NOT NULL,
    end_tx_rua character varying(100) NOT NULL,
    end_int_numero integer NOT NULL,
    end_tx_complemento character varying(20),
    end_tx_bairro character varying(25),
    end_tx_cidade character varying(20),
    end_tx_estado character varying(2)
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_end_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.endereco_end_cd_id_seq OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_end_cd_id_seq OWNED BY public.endereco.end_cd_id;


--
-- Name: pessoa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pessoa (
    pes_cd_id integer NOT NULL,
    pes_tx_nome character varying(50) NOT NULL,
    pes_tx_cpf character varying(14) NOT NULL,
    pes_tx_nascimento date NOT NULL,
    pes_fk_end integer NOT NULL
);


ALTER TABLE public.pessoa OWNER TO postgres;

--
-- Name: pessoa_pes_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pessoa_pes_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pessoa_pes_cd_id_seq OWNER TO postgres;

--
-- Name: pessoa_pes_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pessoa_pes_cd_id_seq OWNED BY public.pessoa.pes_cd_id;


--
-- Name: carro car_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carro ALTER COLUMN car_cd_id SET DEFAULT nextval('public.carro_car_cd_id_seq'::regclass);


--
-- Name: concessionaria conc_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.concessionaria ALTER COLUMN conc_cd_id SET DEFAULT nextval('public.concessionaria_conc_cd_id_seq'::regclass);


--
-- Name: endereco end_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN end_cd_id SET DEFAULT nextval('public.endereco_end_cd_id_seq'::regclass);


--
-- Name: pessoa pes_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa ALTER COLUMN pes_cd_id SET DEFAULT nextval('public.pessoa_pes_cd_id_seq'::regclass);


--
-- Data for Name: carro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carro (car_cd_id, car_tx_nome, car_tx_modelo, car_tx_marca, car_tx_placa, car_int_anofabricacao, car_fl_valor) FROM stdin;
\.
COPY public.carro (car_cd_id, car_tx_nome, car_tx_modelo, car_tx_marca, car_tx_placa, car_int_anofabricacao, car_fl_valor) FROM '$$PATH$$/4815.dat';

--
-- Data for Name: concessionaria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.concessionaria (conc_cd_id, conc_tx_nome, conc_tx_cnpj, conc_tx_telefone, conc_fl_valortotal, conc_dt_datavenda, conc_fk_pes, conc_fk_car, conc_fk_end) FROM stdin;
\.
COPY public.concessionaria (conc_cd_id, conc_tx_nome, conc_tx_cnpj, conc_tx_telefone, conc_fl_valortotal, conc_dt_datavenda, conc_fk_pes, conc_fk_car, conc_fk_end) FROM '$$PATH$$/4817.dat';

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.endereco (end_cd_id, end_tx_cep, end_tx_rua, end_int_numero, end_tx_complemento, end_tx_bairro, end_tx_cidade, end_tx_estado) FROM stdin;
\.
COPY public.endereco (end_cd_id, end_tx_cep, end_tx_rua, end_int_numero, end_tx_complemento, end_tx_bairro, end_tx_cidade, end_tx_estado) FROM '$$PATH$$/4811.dat';

--
-- Data for Name: pessoa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pessoa (pes_cd_id, pes_tx_nome, pes_tx_cpf, pes_tx_nascimento, pes_fk_end) FROM stdin;
\.
COPY public.pessoa (pes_cd_id, pes_tx_nome, pes_tx_cpf, pes_tx_nascimento, pes_fk_end) FROM '$$PATH$$/4813.dat';

--
-- Name: carro_car_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carro_car_cd_id_seq', 5, true);


--
-- Name: concessionaria_conc_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.concessionaria_conc_cd_id_seq', 5, true);


--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_end_cd_id_seq', 5, true);


--
-- Name: pessoa_pes_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pessoa_pes_cd_id_seq', 5, true);


--
-- Name: carro carro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carro
    ADD CONSTRAINT carro_pkey PRIMARY KEY (car_cd_id);


--
-- Name: concessionaria concessionaria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.concessionaria
    ADD CONSTRAINT concessionaria_pkey PRIMARY KEY (conc_cd_id);


--
-- Name: endereco endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (end_cd_id);


--
-- Name: pessoa pessoa_pes_tx_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_pes_tx_cpf_key UNIQUE (pes_tx_cpf);


--
-- Name: pessoa pessoa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_pkey PRIMARY KEY (pes_cd_id);


--
-- Name: concessionaria concessionaria_conc_fk_car_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.concessionaria
    ADD CONSTRAINT concessionaria_conc_fk_car_fkey FOREIGN KEY (conc_fk_car) REFERENCES public.carro(car_cd_id);


--
-- Name: concessionaria concessionaria_conc_fk_end_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.concessionaria
    ADD CONSTRAINT concessionaria_conc_fk_end_fkey FOREIGN KEY (conc_fk_end) REFERENCES public.endereco(end_cd_id);


--
-- Name: concessionaria concessionaria_conc_fk_pes_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.concessionaria
    ADD CONSTRAINT concessionaria_conc_fk_pes_fkey FOREIGN KEY (conc_fk_pes) REFERENCES public.pessoa(pes_cd_id);


--
-- Name: pessoa pessoa_pes_fk_end_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pessoa
    ADD CONSTRAINT pessoa_pes_fk_end_fkey FOREIGN KEY (pes_fk_end) REFERENCES public.endereco(end_cd_id);


--
-- PostgreSQL database dump complete
--

